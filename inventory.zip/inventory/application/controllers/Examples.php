<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Examples extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');
		$this->load->library('session');
		

		$this->load->library('grocery_CRUD');
	}

	public function _example_output($output = null)
	{
		$this->load->view('example.php',(array)$output);
	}

	public function offices()
	{
		$output = $this->grocery_crud->render();

		$this->_example_output($output);
	}

	public function login()
	{
		$this->load->view('login');
	}
	public function form_password()
	{
		$this->load->view('changepass');
		
	}

	public function ganti_password()
	{
		$oldpas = $this->input->post('oldpas');
		$newpas = $this->input->post('newpass');
		$session = $this->session->userdata('username');

		$query = $this->db->get_where('user',['username' => $session, 'password' =>$oldpas])->row_array();

		if($query)
		{
		$this->db->set('password', "'$newpas'" , FALSE);
    	$this->db->where('username', $session);
    	$this->db->update('user');
		}
		else
		{
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password Lama Salah ! </div>');
			redirect('examples/form_password');
		}

		
	}

	public function index()
	{
		if($this->session->userdata('username') == null)
		{
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Anda Belum Login </div>');
			redirect('examples/login');
		}
		else
		{
		$crud = new grocery_CRUD();
		$crud->set_theme('datatables');
		$crud->set_table('assets');
		$crud->display_as('nama','Nama Item')
			->display_as('satuan','Satuan Item')
			->display_as('jumlah','Jumlah Item')
			->display_as('kategori','Kategori Item')
			->display_as('kondisi','Kondisi Item')
			->display_as('foto','Foto Produk');
		$crud->set_subject('Assets');
		$crud->required_fields('nama');
		$crud->set_field_upload('foto','assets/uploads/files');
		$crud->add_fields('nama','satuan','jumlah','kategori','kondisi','foto','session','tanggal');
		$crud->edit_fields('nama','satuan','jumlah','kategori','kondisi','foto');
		if( $crud->getstate() == 'add' ) 
		{
			date_default_timezone_set('Asia/Jakarta'); # add your city to set local time zone
			$tanggal = date('d-m-y');
			$username = $this->session->userdata('username');
			$crud->field_type('session', 'hidden', $username);
			$crud->field_type('tanggal','hidden',$tanggal);
		}
		$output = $crud->render();

		$this->_example_output($output);
		}
	}

	public function auth()
	{
		
		  $username = htmlspecialchars($this->input->post('username'));
		  $password = htmlspecialchars($this->input->post('password'));
		  
		  $user = $this->db->get_where('user',['username' => $username, 'password' =>$password])->row_array();
	  
		  if($user)
		  {
			$data = array(
			  'username' => $username
			);
			$this->session->set_userdata($data);
			redirect('examples',$data);
		  }
		  else{
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Username / Password Salah ! </div>');
			redirect('examples/login');
		  }
		
	}

	public function logout()
	{
		//   $array_items = array('username', 'admin');
		//   $this->session->unset_userdata($array_items);
		//   redirect('auth');
		$this->session->sess_destroy();
		// $this->session->set_flashdata('message', '<div class="alert alert-warning" role="alert">Anda telah Logout! </div>');
		
		
		redirect('examples/login','refresh');
		
	}


	public function offices_management()
	{
		try{
			$crud = new grocery_CRUD();

			$crud->set_theme('datatables');
			$crud->set_table('offices');
			$crud->set_subject('Office');
			$crud->required_fields('city');
			$crud->columns('city','country','phone','addressLine1','postalCode');

			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function employees_management()
	{
			$crud = new grocery_CRUD();
			

			$crud->set_theme('datatables');
			$crud->set_table('assets');
			$crud->display_as('nama','Nama Item')
				->display_as('satuan','Satuan Item')
				->display_as('jumlah','Jumlah Item')
				->display_as('kategori','Kategori Item')
				->display_as('kondisi','Kondisi Item')
				->display_as('foto','Foto Produk');
			$crud->set_subject('Assets');
			$crud->required_fields('nama_item');
			
			$crud->set_field_upload('foto','assets/uploads/files');

			$output = $crud->render();

			$this->_example_output($output);
	}

	

}
